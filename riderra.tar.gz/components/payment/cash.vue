<template>
  <div class="cash-payment">
    <!--<div class="form__item policy">
      <label class="policy__label">
        <input type="checkbox" checked="checked" class="policy__checkbox"> <span>Подтверждаю <a
        href="#" class="policy__link">условия перевозки</a> и <a href="#" class="policy__link">политики конфиценциальности</a></span>
      </label>
    </div>
    <input type="submit" value="Забронировать" class="form__button button">-->
  </div>
</template>
