import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _7a627170 = () => interopDefault(import('../pages/404.vue' /* webpackChunkName: "pages/404" */))
const _58a4ec86 = () => interopDefault(import('../pages/account.vue' /* webpackChunkName: "pages/account" */))
const _c141c042 = () => interopDefault(import('../pages/admin.vue' /* webpackChunkName: "pages/admin" */))
const _2864a44a = () => interopDefault(import('../pages/drivers.vue' /* webpackChunkName: "pages/drivers" */))
const _6e27d123 = () => interopDefault(import('../pages/elite.vue' /* webpackChunkName: "pages/elite" */))
const _443c9d16 = () => interopDefault(import('../pages/payment.vue' /* webpackChunkName: "pages/payment" */))
const _17527a6c = () => interopDefault(import('../pages/places.vue' /* webpackChunkName: "pages/places" */))
const _54746493 = () => interopDefault(import('../pages/success.vue' /* webpackChunkName: "pages/success" */))
const _1b8ab49c = () => interopDefault(import('../pages/test.vue' /* webpackChunkName: "pages/test" */))
const _8bedca8e = () => interopDefault(import('../pages/transport.vue' /* webpackChunkName: "pages/transport" */))
const _6defcbe2 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))
const _5f415552 = () => interopDefault(import('../pages/index/_car.vue' /* webpackChunkName: "pages/index/_car" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/404",
    component: _7a627170,
    name: "404"
  }, {
    path: "/account",
    component: _58a4ec86,
    name: "account"
  }, {
    path: "/admin",
    component: _c141c042,
    name: "admin"
  }, {
    path: "/drivers",
    component: _2864a44a,
    name: "drivers"
  }, {
    path: "/elite",
    component: _6e27d123,
    name: "elite"
  }, {
    path: "/payment",
    component: _443c9d16,
    name: "payment"
  }, {
    path: "/places",
    component: _17527a6c,
    name: "places"
  }, {
    path: "/success",
    component: _54746493,
    name: "success"
  }, {
    path: "/test",
    component: _1b8ab49c,
    name: "test"
  }, {
    path: "/transport",
    component: _8bedca8e,
    name: "transport"
  }, {
    path: "/",
    component: _6defcbe2,
    name: "index",
    children: [{
      path: ":car?",
      component: _5f415552,
      name: "index-car"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
