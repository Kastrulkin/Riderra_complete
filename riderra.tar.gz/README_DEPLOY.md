# 🚀 Деплой Riderra на сервер

## Варианты деплоя

### 1. Docker (Рекомендуется)

#### Быстрый запуск:
```bash
# Клонируйте репозиторий
git clone <your-repo-url>
cd Riderra-main

# Создайте .env файл с переменными окружения
cp .env.example .env
# Отредактируйте .env файл с вашими настройками

# Запустите деплой
./deploy.sh
```

#### Ручной запуск:
```bash
# Создайте директорию для данных
mkdir -p data

# Запустите контейнеры
docker-compose up --build -d

# Проверьте статус
docker-compose ps
```

### 2. Прямой деплой на VPS

#### Требования:
- Node.js 18+
- npm или yarn
- SQLite3

#### Шаги:
```bash
# Установите зависимости
npm install

# Создайте .env файл
cp .env.example .env
# Отредактируйте переменные окружения

# Сгенерируйте Prisma клиент
npx prisma generate

# Примените миграции
npx prisma migrate deploy

# Соберите приложение
npm run build

# Запустите приложение
npm start
```

### 3. Деплой на хостинг-провайдеры

#### Vercel:
1. Подключите GitHub репозиторий к Vercel
2. Установите переменные окружения в настройках проекта
3. Vercel автоматически соберет и задеплоит приложение

#### Netlify:
1. Подключите репозиторий к Netlify
2. Настройте build command: `npm run build`
3. Установите переменные окружения

#### Heroku:
1. Создайте приложение на Heroku
2. Подключите GitHub репозиторий
3. Установите переменные окружения
4. Heroku автоматически соберет и задеплоит

## Переменные окружения

Создайте файл `.env` со следующими переменными:

```env
# База данных
DATABASE_URL="file:./data/prod.db"

# Supabase (если используется)
SUPABASE_URL=your_supabase_url
SUPABASE_ANON_KEY=your_supabase_anon_key

# Админ токен для API
ADMIN_TOKEN=your_secure_admin_token

# Google Maps API
GOOGLE_MAPS_API_KEY=your_google_maps_api_key
```

## Мониторинг и логи

### Docker:
```bash
# Просмотр логов
docker-compose logs -f

# Перезапуск
docker-compose restart

# Остановка
docker-compose down
```

### Прямой деплой:
```bash
# Запуск с PM2 (рекомендуется для продакшена)
npm install -g pm2
pm2 start npm --name "riderra" -- start
pm2 save
pm2 startup
```

## Безопасность

1. **Измените ADMIN_TOKEN** на сложный пароль
2. **Настройте HTTPS** для продакшена
3. **Ограничьте доступ** к админ панели по IP
4. **Регулярно обновляйте** зависимости

## Поддержка

При возникновении проблем:
1. Проверьте логи: `docker-compose logs`
2. Убедитесь, что все переменные окружения установлены
3. Проверьте доступность портов
4. Убедитесь, что база данных инициализирована
