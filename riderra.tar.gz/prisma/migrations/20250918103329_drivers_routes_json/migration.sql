-- AlterTable
ALTER TABLE "Driver" ADD COLUMN "fixedRoutesJson" TEXT;
