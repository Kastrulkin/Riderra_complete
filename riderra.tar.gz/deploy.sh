#!/bin/bash

# Скрипт для деплоя Riderra на сервер

echo "🚀 Начинаем деплой Riderra..."

# Проверяем наличие Docker
if ! command -v docker &> /dev/null; then
    echo "❌ Docker не установлен. Установите Docker и попробуйте снова."
    exit 1
fi

# Проверяем наличие docker-compose
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose не установлен. Установите Docker Compose и попробуйте снова."
    exit 1
fi

# Создаем директорию для данных
mkdir -p data

# Останавливаем существующие контейнеры
echo "🛑 Останавливаем существующие контейнеры..."
docker-compose down

# Собираем и запускаем контейнеры
echo "🔨 Собираем и запускаем контейнеры..."
docker-compose up --build -d

# Ждем запуска
echo "⏳ Ждем запуска приложения..."
sleep 10

# Проверяем статус
if docker-compose ps | grep -q "Up"; then
    echo "✅ Приложение успешно запущено!"
    echo "🌐 Приложение доступно по адресу: http://localhost:3000"
    echo "📊 Статус контейнеров:"
    docker-compose ps
else
    echo "❌ Ошибка при запуске приложения"
    echo "📋 Логи:"
    docker-compose logs
    exit 1
fi
